To run the makeChange.cpp file you will use the g++ compiler on the flip servers.  You will also need to make sure that a data.txt file is provided in the same directory. 

To compile use:

g++ makeChange.cpp

./a.out

This will run the program and output the information to change.txt
