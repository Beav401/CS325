In order to run this program, first make sure that the shopping.cpp file is in the same directory as shopping.txt.

Then you can use the g++ compiler as:

g++ shopping.cpp

./a.out

This will run the program and output the results into result.txt
