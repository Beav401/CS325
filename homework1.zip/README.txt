Author: Reed Boeshans
Date: 4/5/2020

All code written for this assignment is in c++. To compile this on the Engr servers I used the g++ compiler. An example of running insertsort.cpp can be seen below:

	g++ insertsort.cpp
	./a.out

You can then check intsert.out for the output of this sorting method.
THe other files can be compiled in the same way.
