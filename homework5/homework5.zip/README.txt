To run this file on the flip servers make sure that you have a wrestler file already in the same directory.

Then you can use the g++ compiler to copmile such as:

g++ rivalWrestlers.cpp

Then you can run the program with:

./a.out {file name} 

where file name is the name of your txt file with the wrestler data inside.
The result will be outputted to the terminal.
