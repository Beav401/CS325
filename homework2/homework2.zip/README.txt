The file that you will be compiling is badSort.cpp 

TO compile this program you will use the g++ compiler as such:

g++ -std=c++11 badSort.cpp
./a.out .75

The .75 after the executable is used to assign the alpha value. You can input any decimal value here.

The program will then output the sorted arrays into bad.out
